"""
Module 1: Language Detection

Approach: traditional NLP as required by the brief -- a character n-gram
TF-IDF vectorizer feeding a linear classifier.

Design choices / "enhancements" beyond the minimal ask:
  - Character n-grams (2-5) instead of word n-grams. Language ID is a
    sub-word-level signal (letter combinations, diacritics, accented
    sequences) so char n-grams dramatically outperform word-level TF-IDF,
    especially on short customer messages and languages without whitespace
    tokenization (e.g. Chinese, Japanese).
  - Lowercasing but NOT stripping accents, since accents are exactly the
    signal that separates e.g. Spanish/French/Portuguese.
  - LinearSVC (via CalibratedClassifierCV for probability estimates) rather
    than plain LogisticRegression: LinearSVC tends to edge out on sparse
    high-dimensional char n-gram features and is fast to train on 90k rows.
  - A lightweight "confidence gate": if the top prediction's probability is
    below a threshold, we fall back to "en" (or flag low-confidence) rather
    than confidently guessing, since a wrong language guess breaks
    downstream KB retrieval.
"""
from __future__ import annotations

import joblib
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from .paths import data_path, models_path

MODEL_PATH = models_path("language_detector.joblib")
LOW_CONFIDENCE_THRESHOLD = 0.35


def load_hf_dataset() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Load the real papluca/language-identification dataset (needs internet
    access to huggingface.co). Falls back to the bundled CSV sample when the
    `datasets` library or network isn't available, so this module is always
    runnable end to end for local development/testing."""
    try:
        from datasets import load_dataset

        ds = load_dataset("papluca/language-identification")
        train_df = ds["train"].to_pandas()
        val_df = ds["validation"].to_pandas()
        test_df = ds["test"].to_pandas()
        return train_df, val_df, test_df
    except Exception as e:  # pragma: no cover - network/env dependent
        print(f"[language_detection] Falling back to sample data ({e})")
        df = pd.read_csv(data_path("sample_language_id.csv"))
        # The bundled sample is tiny (a handful of rows per language), so we
        # skip stratification here -- the real HF dataset (90k rows) is
        # stratified fine by the library's own pre-made splits.
        train_df, temp_df = train_test_split(df, test_size=0.4, random_state=42)
        val_df, test_df = train_test_split(temp_df, test_size=0.5, random_state=42)
        return train_df, val_df, test_df


def build_pipeline(cv_folds: int = 3) -> Pipeline:
    vectorizer = TfidfVectorizer(
        analyzer="char_wb",
        ngram_range=(2, 5),
        lowercase=True,
        min_df=1,
        sublinear_tf=True,
    )
    base_clf = LinearSVC(C=1.0, class_weight="balanced")
    clf = CalibratedClassifierCV(base_clf, cv=cv_folds)
    return Pipeline([("tfidf", vectorizer), ("clf", clf)])


def train(train_df: pd.DataFrame, val_df: pd.DataFrame | None = None) -> Pipeline:
    # CalibratedClassifierCV needs at least `cv` examples per class; the real
    # 90k-row HF dataset comfortably supports cv=3, but the tiny bundled demo
    # sample may not, so we adapt automatically and fall back to an
    # uncalibrated LinearSVC (decision_function-based confidence) if even
    # cv=2 isn't feasible for the smallest class.
    min_class_count = train_df["labels"].value_counts().min()
    if min_class_count >= 2:
        cv_folds = max(2, min(3, int(min_class_count)))
        pipeline = build_pipeline(cv_folds=cv_folds)
    else:
        print(
            "[language_detection] A class has <2 samples; skipping probability "
            "calibration for this run (fine on the full 90k-row HF dataset)."
        )
        vectorizer = TfidfVectorizer(
            analyzer="char_wb", ngram_range=(2, 5), lowercase=True,
            min_df=1, sublinear_tf=True,
        )
        pipeline = Pipeline([
            ("tfidf", vectorizer),
            ("clf", LinearSVC(C=1.0, class_weight="balanced")),
        ])
    pipeline.fit(train_df["text"], train_df["labels"])
    if val_df is not None and len(val_df):
        preds = pipeline.predict(val_df["text"])
        print(classification_report(val_df["labels"], preds, zero_division=0))
    return pipeline


def evaluate(pipeline: Pipeline, test_df: pd.DataFrame) -> None:
    preds = pipeline.predict(test_df["text"])
    print(classification_report(test_df["labels"], preds, zero_division=0))


def predict_language(pipeline: Pipeline, text: str) -> dict:
    classes = pipeline.classes_
    if hasattr(pipeline, "predict_proba"):
        proba = pipeline.predict_proba([text])[0]
    else:
        # Uncalibrated LinearSVC fallback: softmax over decision_function
        # margins as a rough, monotonic confidence proxy.
        import numpy as np

        scores = pipeline.decision_function([text])[0]
        scores = np.atleast_1d(scores)
        exp = np.exp(scores - scores.max())
        proba = exp / exp.sum()
    best_idx = proba.argmax()
    label = classes[best_idx]
    confidence = float(proba[best_idx])
    low_confidence = confidence < LOW_CONFIDENCE_THRESHOLD
    return {
        "language": label if not low_confidence else "en",
        "confidence": confidence,
        "low_confidence": low_confidence,
    }


def save(pipeline: Pipeline, path: str = MODEL_PATH) -> None:
    joblib.dump(pipeline, path)


def load(path: str = MODEL_PATH) -> Pipeline:
    return joblib.load(path)


if __name__ == "__main__":
    train_df, val_df, test_df = load_hf_dataset()
    pipeline = train(train_df, val_df)
    evaluate(pipeline, test_df)
    save(pipeline)
    print(predict_language(pipeline, "Hello, where is my order?"))
