"""Path helpers so modules work the same whether invoked from the project
root, from notebooks/, or via `python -m`."""
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(PROJECT_ROOT, "data")
MODELS_DIR = os.path.join(PROJECT_ROOT, "models")


def data_path(filename: str) -> str:
    return os.path.join(DATA_DIR, filename)


def models_path(filename: str) -> str:
    return os.path.join(MODELS_DIR, filename)
