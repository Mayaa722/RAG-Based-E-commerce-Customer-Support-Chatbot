"""
End-to-end orchestration: language -> sentiment -> intent -> route -> respond.

Design decision on complaint/negative-sentiment routing (documented per the
brief's requirement to justify this choice):

  We chose ESCALATION over auto-apology-then-answer for the `complaint`
  coarse-intent bucket specifically (not just any negative sentiment). A
  complaint/review is fundamentally different from a frustrated customer
  asking a normal support question (e.g. "I'm furious my refund is late,
  where is it?" -- still order_status/billing intent, just negative tone).
  For genuine complaints, auto-generating a response risks sounding
  dismissive or making commitments the company can't keep, so we flag these
  for human review with a holding message instead of an LLM-generated reply.

  For any OTHER intent bucket where sentiment is negative, we keep
  auto-response but PREPEND an empathetic acknowledgment before the
  RAG-generated answer (handled inside the RAG system prompt via the
  {detected_sentiment} slot), rather than escalating -- this keeps routine
  questions (order status, account changes) self-served while still
  adjusting tone, which is what the brief asks for as the "adjusting tone"
  behavior distinct from full escalation.
"""
from __future__ import annotations

from . import intent_mapping


SMALL_TALK_RESPONSES = {
    "greeting_goodbye_gratitude": "Hello! Welcome to our support chat. How can I help you today?",
}

ESCALATION_MESSAGE = (
    "I'm really sorry to hear about your experience, and I understand this is "
    "frustrating. I've flagged your message for priority review by a member of "
    "our team, who will follow up with you directly as soon as possible."
)

OUT_OF_SCOPE_MESSAGE = (
    "I'm here to help with orders, billing, deliveries, and account questions "
    "for our store. I'm not able to help with that, but I'm happy to assist "
    "with anything related to your account or orders!"
)


class SupportPipeline:
    def __init__(self, lang_pipeline, sentiment_bundle, intent_pipeline, embedder, rag_store):
        self.lang_pipeline = lang_pipeline
        self.sentiment_model, self.sentiment_vocab, self.sentiment_label2id = sentiment_bundle
        self.intent_pipeline = intent_pipeline
        self.embedder = embedder
        self.rag_store = rag_store

    def handle_message(self, user_message: str) -> dict:
        from . import language_detection, sentiment_classifier, intent_classifier, rag_pipeline

        lang_result = language_detection.predict_language(self.lang_pipeline, user_message)
        sentiment_result = sentiment_classifier.predict_sentiment(
            self.sentiment_model, self.sentiment_vocab, self.sentiment_label2id, user_message
        )
        intent_result = intent_classifier.predict_intent(self.intent_pipeline, user_message)

        coarse_intent = intent_result["coarse_intent"]
        behavior = intent_mapping.ROUTE_BEHAVIOR[coarse_intent]

        if behavior == "direct" and coarse_intent == "greeting_goodbye_gratitude":
            answer = SMALL_TALK_RESPONSES[coarse_intent]
            retrieved = []
        elif behavior == "direct":  # out_of_scope
            answer = OUT_OF_SCOPE_MESSAGE
            retrieved = []
        elif behavior == "escalate":
            answer = ESCALATION_MESSAGE
            retrieved = []
        else:  # "rag"
            rag_result = rag_pipeline.answer_query(
                user_message, self.embedder, self.rag_store,
                sentiment=sentiment_result["bucket"],
            )
            answer = rag_result["answer"]
            retrieved = rag_result["retrieved"]

        return {
            "answer": answer,
            "language": lang_result,
            "sentiment": sentiment_result,
            "intent": intent_result,
            "routing_behavior": behavior,
            "retrieved_context": retrieved,
        }
