"""
Module 2: Sentiment / Emotion Classifier

Approach: Recurrent Neural Network (BiLSTM) as one of the two options in the
brief. An RNN was chosen over a transformer here deliberately:
  - The 6-emotion dair-ai/emotion dataset is short, single-sentence Twitter
    text (~20k rows) -- a BiLSTM with pretrained-style embeddings trains in
    minutes on CPU and is easy to reason about/debug for the oral
    assessment, whereas fine-tuning a transformer needs a GPU to be
    practical and is harder to fully "grasp" line-by-line as requested in
    the brief's notes.
  - A transformer (e.g. DistilBERT) is noted below as the natural upgrade
    path if higher accuracy is needed and GPU time is available.

Design choices:
  - 6 fine-grained emotions (sadness, joy, love, anger, fear, surprise) are
    trained first (this is what the labeled dataset gives us), then mapped
    down to 3 routing buckets: negative={sadness,anger,fear},
    positive={joy,love}, neutral={surprise}. Surprise is kept neutral by
    default since it's valence-ambiguous (could be a pleasant or unpleasant
    surprise) -- documented here as a design decision to defend at
    assessment.
  - Domain-shift caveat (Twitter vs. customer-support text) is handled by
    keeping the qualitative sample set in data/sample_emotion.csv written in
    a customer-support register, used as a sanity check independent of the
    Twitter-trained model.
"""
from __future__ import annotations

import json
import re
from collections import Counter

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split

from .paths import data_path, models_path

MODEL_DIR = models_path("sentiment")
MAX_LEN = 40
EMBED_DIM = 100
HIDDEN_DIM = 64
BATCH_SIZE = 32
EPOCHS = 5
PAD_TOKEN, UNK_TOKEN = "<pad>", "<unk>"

EMOTION_TO_BUCKET = {
    "sadness": "negative",
    "anger": "negative",
    "fear": "negative",
    "joy": "positive",
    "love": "positive",
    "surprise": "neutral",
    "neutral": "neutral",
}


def load_hf_dataset() -> pd.DataFrame:
    try:
        from datasets import load_dataset

        ds = load_dataset("dair-ai/emotion")
        df = pd.concat(
            [ds["train"].to_pandas(), ds["validation"].to_pandas(), ds["test"].to_pandas()],
            ignore_index=True,
        )
        id2label = ds["train"].features["label"].int2str
        df["label"] = df["label"].apply(id2label)
        return df
    except Exception as e:  # pragma: no cover
        print(f"[sentiment_classifier] Falling back to sample data ({e})")
        return pd.read_csv(data_path("sample_emotion.csv"))


def clean_text(text: str) -> str:
    text = text.lower()
    text = re.sub(r"http\S+|www\S+", " ", text)
    text = re.sub(r"[^a-zA-Z'\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def build_vocab(texts: list[str], min_freq: int = 1, max_size: int = 20000) -> dict:
    counter = Counter(tok for t in texts for tok in t.split())
    vocab = {PAD_TOKEN: 0, UNK_TOKEN: 1}
    for tok, freq in counter.most_common(max_size):
        if freq >= min_freq:
            vocab[tok] = len(vocab)
    return vocab


def encode(text: str, vocab: dict, max_len: int = MAX_LEN) -> list[int]:
    ids = [vocab.get(tok, vocab[UNK_TOKEN]) for tok in text.split()][:max_len]
    ids += [vocab[PAD_TOKEN]] * (max_len - len(ids))
    return ids


class EmotionDataset:
    """Thin wrapper so this module also works without torch installed
    (e.g. for the char-level baseline), while the primary path uses torch."""

    def __init__(self, encoded, labels):
        self.encoded = encoded
        self.labels = labels

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, idx):
        return self.encoded[idx], self.labels[idx]


def build_torch_model(vocab_size: int, n_classes: int):
    import torch
    import torch.nn as nn

    class BiLSTMClassifier(nn.Module):
        def __init__(self):
            super().__init__()
            self.embedding = nn.Embedding(vocab_size, EMBED_DIM, padding_idx=0)
            self.lstm = nn.LSTM(
                EMBED_DIM, HIDDEN_DIM, batch_first=True, bidirectional=True
            )
            self.dropout = nn.Dropout(0.3)
            self.fc = nn.Linear(HIDDEN_DIM * 2, n_classes)

        def forward(self, x):
            emb = self.embedding(x)
            out, (h, _) = self.lstm(emb)
            h_cat = torch.cat([h[0], h[1]], dim=1)  # concat fwd/bwd final states
            return self.fc(self.dropout(h_cat))

    return BiLSTMClassifier()


def train(df: pd.DataFrame, allow_sklearn_fallback: bool = True):
    """Train the BiLSTM emotion classifier. Requires torch. If torch isn't
    installed (e.g. a restricted/offline environment) and
    `allow_sklearn_fallback=True`, trains a TF-IDF + Logistic Regression
    classifier instead so the rest of the pipeline (routing, app, demos)
    stays runnable. This fallback is for local development/testing only --
    the graded deliverable is the BiLSTM/transformer described in the module
    docstring above."""
    try:
        import torch
        from torch.utils.data import DataLoader
    except Exception as e:  # ImportError, or a broken/partial torch install
        if not allow_sklearn_fallback:
            raise ImportError(
                "PyTorch is required to train the sentiment model. "
                "Install with `pip install torch --break-system-packages`."
            ) from e
        print(
            "[sentiment_classifier] torch not installed; training a TF-IDF + "
            "LogisticRegression fallback model for local testing. Install "
            "torch to train the real BiLSTM deliverable model."
        )
        return _train_sklearn_fallback(df)

    df = df.copy()
    df["clean"] = df["text"].apply(clean_text)
    labels = sorted(df["label"].unique())
    label2id = {l: i for i, l in enumerate(labels)}

    n_classes = df["label"].nunique()
    can_stratify = df["label"].value_counts().min() >= 2 and len(df) >= n_classes * 5
    train_df, val_df = train_test_split(
        df, test_size=0.2, random_state=42,
        stratify=df["label"] if can_stratify else None,
    )

    vocab = build_vocab(train_df["clean"].tolist())
    X_train = [encode(t, vocab) for t in train_df["clean"]]
    y_train = [label2id[l] for l in train_df["label"]]
    X_val = [encode(t, vocab) for t in val_df["clean"]]
    y_val = [label2id[l] for l in val_df["label"]]

    train_ds = EmotionDataset(
        torch.tensor(X_train, dtype=torch.long), torch.tensor(y_train, dtype=torch.long)
    )
    train_loader = DataLoader(train_ds, batch_size=min(BATCH_SIZE, len(train_ds)), shuffle=True)

    model = build_torch_model(len(vocab), len(labels))
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    criterion = torch.nn.CrossEntropyLoss()

    model.train()
    for epoch in range(EPOCHS):
        total_loss = 0.0
        for xb, yb in train_loader:
            optimizer.zero_grad()
            logits = model(xb)
            loss = criterion(logits, yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(xb)
        print(f"epoch {epoch + 1}/{EPOCHS} - train loss {total_loss / len(train_ds):.4f}")

    model.eval()
    with torch.no_grad():
        val_logits = model(torch.tensor(X_val, dtype=torch.long))
        val_preds = val_logits.argmax(dim=1).tolist()
    id2label = {i: l for l, i in label2id.items()}
    print(
        classification_report(
            [id2label[i] for i in y_val],
            [id2label[i] for i in val_preds],
            zero_division=0,
        )
    )

    return model, vocab, label2id


def _train_sklearn_fallback(df: pd.DataFrame):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline

    df = df.copy()
    df["clean"] = df["text"].apply(clean_text)
    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=1)),
        ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
    ])
    n_classes = df["label"].nunique()
    can_stratify = df["label"].value_counts().min() >= 2 and len(df) >= n_classes * 5
    train_df, val_df = train_test_split(
        df, test_size=0.2, random_state=42,
        stratify=df["label"] if can_stratify else None,
    )
    pipeline.fit(train_df["clean"], train_df["label"])
    if len(val_df):
        preds = pipeline.predict(val_df["clean"])
        print(classification_report(val_df["label"], preds, zero_division=0))
    # Wrap so predict_sentiment()/save()/load() have a uniform interface:
    # "model" here is the sklearn pipeline, vocab is None, label2id is None.
    return pipeline, None, {"__sklearn_fallback__": True}


def predict_sentiment(model, vocab, label2id, text: str) -> dict:
    if label2id.get("__sklearn_fallback__") if isinstance(label2id, dict) else False:
        clean = clean_text(text)
        proba = model.predict_proba([clean])[0]
        classes = model.classes_
        best_idx = proba.argmax()
        emotion = classes[best_idx]
        bucket = EMOTION_TO_BUCKET.get(emotion, "neutral")
        return {"emotion": emotion, "bucket": bucket, "confidence": float(proba[best_idx])}
    return _predict_sentiment_torch(model, vocab, label2id, text)


def _predict_sentiment_torch(model, vocab, label2id, text: str) -> dict:
    import torch

    id2label = {i: l for l, i in label2id.items()}
    clean = clean_text(text)
    ids = torch.tensor([encode(clean, vocab)], dtype=torch.long)
    model.eval()
    with torch.no_grad():
        logits = model(ids)
        proba = torch.softmax(logits, dim=1)[0]
        best_idx = int(proba.argmax())
    emotion = id2label[best_idx]
    bucket = EMOTION_TO_BUCKET.get(emotion, "neutral")
    return {
        "emotion": emotion,
        "bucket": bucket,
        "confidence": float(proba[best_idx]),
    }


def save(model, vocab, label2id, out_dir: str = MODEL_DIR) -> None:
    import os

    os.makedirs(out_dir, exist_ok=True)

    if isinstance(label2id, dict) and label2id.get("__sklearn_fallback__"):
        joblib.dump(model, f"{out_dir}/sklearn_fallback.joblib")
        with open(f"{out_dir}/mode.json", "w") as f:
            json.dump({"mode": "sklearn_fallback"}, f)
        return

    import torch

    torch.save(model.state_dict(), f"{out_dir}/model.pt")
    with open(f"{out_dir}/vocab.json", "w") as f:
        json.dump(vocab, f)
    with open(f"{out_dir}/label2id.json", "w") as f:
        json.dump(label2id, f)
    with open(f"{out_dir}/config.json", "w") as f:
        json.dump(
            {"embed_dim": EMBED_DIM, "hidden_dim": HIDDEN_DIM, "max_len": MAX_LEN}, f
        )
    with open(f"{out_dir}/mode.json", "w") as f:
        json.dump({"mode": "torch"}, f)


def load(out_dir: str = MODEL_DIR):
    with open(f"{out_dir}/mode.json") as f:
        mode = json.load(f)["mode"]

    if mode == "sklearn_fallback":
        model = joblib.load(f"{out_dir}/sklearn_fallback.joblib")
        return model, None, {"__sklearn_fallback__": True}

    import torch

    with open(f"{out_dir}/vocab.json") as f:
        vocab = json.load(f)
    with open(f"{out_dir}/label2id.json") as f:
        label2id = json.load(f)
    model = build_torch_model(len(vocab), len(label2id))
    model.load_state_dict(torch.load(f"{out_dir}/model.pt"))
    model.eval()
    return model, vocab, label2id


if __name__ == "__main__":
    df = load_hf_dataset()
    model, vocab, label2id = train(df)
    save(model, vocab, label2id)
    print(predict_sentiment(model, vocab, label2id, "this is the worst experience ever, so angry"))
