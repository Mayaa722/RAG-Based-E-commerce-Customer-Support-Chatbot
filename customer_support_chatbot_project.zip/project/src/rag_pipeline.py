"""
Module 4: Q&A RAG Pipeline

Components (per the brief):
  - Embeddings: sentence-transformers `all-MiniLM-L6-v2` (fast, 384-dim,
    strong general-purpose semantic similarity, CPU-friendly).
  - Vector store: FAISS (local, in-memory) by default -- chosen over a
    hosted Qdrant Cloud instance to avoid an external account dependency
    for local development and the assessment run. A `QdrantStore` adapter
    is also included and is a drop-in swap (same `.search()` interface) if
    a persistent/shared vector DB is preferred.
  - LLM: Groq API (`gpt-oss-120b` by default, `gpt-oss-20b` as a faster/
    cheaper fallback), called with the retrieved chunks injected into the
    brief's suggested prompt template.

Retrieval unit: each Bitext row's `instruction` (customer question) is
embedded and indexed; on retrieval we pull back the paired `response`
(the grounding "answer" text) for the top-k nearest instructions, which
directly matches the brief's guidance ("embed the instructions for
retrieval, inject the paired responses as grounding context").
"""
from __future__ import annotations

import os
import pickle

import numpy as np
import pandas as pd

from .paths import data_path, models_path

EMBED_MODEL_NAME = "all-MiniLM-L6-v2"
INDEX_PATH = models_path("rag_index.faiss")
META_PATH = models_path("rag_meta.pkl")
TOP_K = 3
GROQ_MODEL = "openai/gpt-oss-120b"
GROQ_MODEL_FALLBACK = "openai/gpt-oss-20b"


def load_hf_dataset() -> pd.DataFrame:
    try:
        from datasets import load_dataset

        ds = load_dataset(
            "bitext/Bitext-customer-support-llm-chatbot-training-dataset"
        )
        return ds["train"].to_pandas()
    except Exception as e:  # pragma: no cover
        print(f"[rag_pipeline] Falling back to sample data ({e})")
        return pd.read_csv(data_path("sample_support_kb.csv"))


class Embedder:
    """Wraps sentence-transformers; falls back to a TF-IDF vectorizer (so
    the retrieval pipeline is still runnable/testable without the ~90MB
    model download) with a clearly logged warning."""

    def __init__(self, model_name: str = EMBED_MODEL_NAME):
        self.model_name = model_name
        try:
            from sentence_transformers import SentenceTransformer

            self.model = SentenceTransformer(model_name)
            self.backend = "sentence-transformers"
        except Exception as e:  # pragma: no cover
            print(f"[rag_pipeline] sentence-transformers unavailable ({e}); "
                  f"falling back to TF-IDF embeddings for local testing.")
            from sklearn.feature_extraction.text import TfidfVectorizer

            self.model = TfidfVectorizer(max_features=2048)
            self.backend = "tfidf"
            self._fitted = False

    def encode(self, texts: list[str]) -> np.ndarray:
        if self.backend == "sentence-transformers":
            return np.asarray(self.model.encode(texts, normalize_embeddings=True))
        # tfidf fallback
        if not getattr(self, "_fitted", False):
            mat = self.model.fit_transform(texts)
            self._fitted = True
        else:
            mat = self.model.transform(texts)
        mat = mat.toarray().astype("float32")
        norms = np.linalg.norm(mat, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        return mat / norms


class FaissStore:
    """Local FAISS index over instruction embeddings, storing (instruction,
    response, intent, category) as retrievable metadata."""

    def __init__(self, dim: int):
        import faiss

        self.index = faiss.IndexFlatIP(dim)  # cosine sim via normalized dot product
        self.meta: list[dict] = []

    def add(self, vectors: np.ndarray, meta: list[dict]) -> None:
        self.index.add(vectors.astype("float32"))
        self.meta.extend(meta)

    def search(self, query_vec: np.ndarray, top_k: int = TOP_K) -> list[dict]:
        scores, idxs = self.index.search(query_vec.astype("float32"), top_k)
        results = []
        for score, idx in zip(scores[0], idxs[0]):
            if idx == -1:
                continue
            row = dict(self.meta[idx])
            row["score"] = float(score)
            results.append(row)
        return results

    def save(self, index_path: str = INDEX_PATH, meta_path: str = META_PATH) -> None:
        import faiss

        os.makedirs(os.path.dirname(index_path), exist_ok=True)
        faiss.write_index(self.index, index_path)
        with open(meta_path, "wb") as f:
            pickle.dump(self.meta, f)

    @classmethod
    def load(cls, index_path: str = INDEX_PATH, meta_path: str = META_PATH) -> "FaissStore":
        import faiss

        store = cls.__new__(cls)
        store.index = faiss.read_index(index_path)
        with open(meta_path, "rb") as f:
            store.meta = pickle.load(f)
        return store


class QdrantStore:
    """Drop-in alternative to FaissStore backed by a (free-tier) Qdrant
    Cloud cluster. Same add()/search() interface. Requires QDRANT_URL and
    QDRANT_API_KEY env vars."""

    def __init__(self, dim: int, collection: str = "support_kb"):
        from qdrant_client import QdrantClient
        from qdrant_client.models import Distance, VectorParams

        self.client = QdrantClient(
            url=os.environ["QDRANT_URL"], api_key=os.environ.get("QDRANT_API_KEY")
        )
        self.collection = collection
        self.dim = dim
        if not self.client.collection_exists(collection):
            self.client.create_collection(
                collection_name=collection,
                vectors_config=VectorParams(size=dim, distance=Distance.COSINE),
            )
        self._next_id = 0

    def add(self, vectors: np.ndarray, meta: list[dict]) -> None:
        from qdrant_client.models import PointStruct

        points = [
            PointStruct(id=self._next_id + i, vector=v.tolist(), payload=m)
            for i, (v, m) in enumerate(zip(vectors, meta))
        ]
        self.client.upsert(collection_name=self.collection, points=points)
        self._next_id += len(points)

    def search(self, query_vec: np.ndarray, top_k: int = TOP_K) -> list[dict]:
        hits = self.client.search(
            collection_name=self.collection, query_vector=query_vec[0].tolist(), limit=top_k
        )
        return [{**h.payload, "score": h.score} for h in hits]


def build_index(df: pd.DataFrame, embedder: Embedder) -> FaissStore:
    texts = df["instruction"].tolist()
    vectors = embedder.encode(texts)
    meta = df[["instruction", "response", "intent", "category"]].to_dict("records")
    store = FaissStore(dim=vectors.shape[1])
    store.add(vectors, meta)
    return store


SYSTEM_PROMPT_TEMPLATE = """You are a helpful, professional customer support assistant
  for an online retailer. Answer the customer's question using ONLY
  the information in the retrieved support responses below. If the
  customer sounds frustrated ({detected_sentiment}), acknowledge
  that before answering. If the retrieved context does not cover
  the question, say so honestly and offer to escalate to a human
  agent rather than guessing."""

USER_PROMPT_TEMPLATE = """Context (retrieved past support responses):
{retrieved_chunks}

Customer question: "{user_message}\""""


def build_prompt(user_message: str, retrieved: list[dict], sentiment: str) -> tuple[str, str]:
    chunks = "\n".join(f"- {r['response']}" for r in retrieved) or "(no relevant context found)"
    system = SYSTEM_PROMPT_TEMPLATE.format(detected_sentiment=sentiment)
    user = USER_PROMPT_TEMPLATE.format(retrieved_chunks=chunks, user_message=user_message)
    return system, user


def generate_answer(
    user_message: str, retrieved: list[dict], sentiment: str = "neutral",
    model: str = GROQ_MODEL,
) -> str:
    """Calls the Groq API. Requires GROQ_API_KEY env var. Falls back to a
    templated, purely-extractive answer (no LLM call) if groq isn't
    configured, so the pipeline is still testable offline."""
    system, user = build_prompt(user_message, retrieved, sentiment)
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        print("[rag_pipeline] GROQ_API_KEY not set; using extractive fallback answer.")
        if not retrieved:
            return (
                "I couldn't find anything relevant to that in our knowledge base. "
                "I don't want to guess, so let me connect you with a human agent "
                "who can help further."
            )
        return retrieved[0]["response"]

    try:
        from groq import Groq

        client = Groq(api_key=api_key)
        completion = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            temperature=0.3,
            max_tokens=400,
        )
        return completion.choices[0].message.content
    except Exception as e:  # pragma: no cover
        print(f"[rag_pipeline] Groq call failed ({e}); using extractive fallback.")
        return retrieved[0]["response"] if retrieved else (
            "I'm sorry, I couldn't generate a grounded answer right now. "
            "Let me escalate this to a human agent."
        )


def answer_query(
    user_message: str, embedder: Embedder, store: FaissStore,
    sentiment: str = "neutral", top_k: int = TOP_K,
) -> dict:
    query_vec = embedder.encode([user_message])
    retrieved = store.search(query_vec, top_k=top_k)
    answer = generate_answer(user_message, retrieved, sentiment)
    return {"answer": answer, "retrieved": retrieved}


if __name__ == "__main__":
    df = load_hf_dataset()
    embedder = Embedder()
    store = build_index(df, embedder)
    result = answer_query("Where is my order? It hasn't shipped yet.", embedder, store)
    print(result["answer"])
    for r in result["retrieved"]:
        print(f"  [{r['score']:.3f}] {r['intent']}: {r['instruction']}")
