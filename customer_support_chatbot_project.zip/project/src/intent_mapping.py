"""
Coarse intent taxonomy used for routing.

The Bitext dataset ships 27 fine-grained intents across 10 categories. For
routing purposes we condense these into 7 coarse buckets as specified in the
task brief. Fine-grained labels are still trained/predicted first (they are
what the dataset gives us gold labels for) and then mapped down to the coarse
bucket for routing logic.
"""

# fine-grained intent -> coarse routing bucket
FINE_TO_COARSE = {
    # small talk, no retrieval needed
    "greet": "greeting_goodbye_gratitude",
    "greeting": "greeting_goodbye_gratitude",
    "bye": "greeting_goodbye_gratitude",
    "goodbye": "greeting_goodbye_gratitude",
    "thank": "greeting_goodbye_gratitude",
    "gratitude": "greeting_goodbye_gratitude",

    # order status
    "track_order": "order_status",
    "delivery_options": "order_status",
    "delivery_period": "order_status",

    # order management
    "cancel_order": "order_management",
    "change_order": "order_management",
    "place_order": "order_management",

    # billing and refunds
    "check_invoice": "billing_and_refunds",
    "get_refund": "billing_and_refunds",
    "payment_issue": "billing_and_refunds",
    "get_invoice": "billing_and_refunds",
    "check_refund_policy": "billing_and_refunds",
    "track_refund": "billing_and_refunds",

    # account management
    "create_account": "account_management",
    "edit_account": "account_management",
    "delete_account": "account_management",
    "switch_account": "account_management",
    "recover_password": "account_management",
    "registration_problems": "account_management",

    # complaint / review -> always priority-flagged
    "complaint": "complaint",
    "review": "complaint",

    # newsletter / cancellation fee / shipping address don't map cleanly to
    # the 7 buckets above; we fold them into the closest operational bucket
    "newsletter_subscription": "account_management",
    "cancellation_fee": "billing_and_refunds",
    "set_up_shipping_address": "order_management",
    "change_shipping_address": "order_management",

    "out_of_scope": "out_of_scope",
}

COARSE_LABELS = [
    "greeting_goodbye_gratitude",
    "order_status",
    "order_management",
    "billing_and_refunds",
    "account_management",
    "complaint",
    "out_of_scope",
]

# Routing behaviour per coarse bucket, referenced by app/pipeline.py
# - "direct": answer directly, no RAG call needed
# - "rag": run full RAG retrieval + generation
# - "escalate": prepend empathetic acknowledgment, flag for human review
ROUTE_BEHAVIOR = {
    "greeting_goodbye_gratitude": "direct",
    "order_status": "rag",
    "order_management": "rag",
    "billing_and_refunds": "rag",
    "account_management": "rag",
    "complaint": "escalate",
    "out_of_scope": "direct",
}


def to_coarse(fine_label: str) -> str:
    """Map a fine-grained Bitext intent label to its coarse routing bucket."""
    return FINE_TO_COARSE.get(fine_label, "out_of_scope")
