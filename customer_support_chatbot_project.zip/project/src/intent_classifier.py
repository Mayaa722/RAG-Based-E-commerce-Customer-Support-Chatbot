"""
Module 3: Intent Classifier

Approach: traditional supervised ML (TF-IDF + Linear SVM) directly on the
Bitext dataset's gold `intent` column, as recommended in the brief -- this is
a genuine supervised classification task, not zero/few-shot, since labels
already exist.

Design choices:
  - Word-level TF-IDF (unigrams + bigrams) is the right granularity here
    (unlike language ID): intent is carried by content words/phrases
    ("cancel", "refund", "track my order"), not by sub-word character
    patterns.
  - LinearSVC with class_weight="balanced" to handle the natural class
    imbalance across the 27 fine intents (e.g. far more "track_order"
    examples than "delete_account" in typical support logs).
  - We train and evaluate on the FINE-grained gold labels (27 classes) --
    this is what the dataset actually supervises and what should be
    reported/defended at assessment -- then apply a deterministic mapping
    (src/intent_mapping.py) down to the 7 coarse routing buckets used by the
    orchestration pipeline. Doing the mapping post-hoc (rather than training
    directly on 7 collapsed classes) keeps the fine-grained signal available
    for future routing refinements and matches how the dataset is actually
    labeled.
  - `complaint` / `review` are always coarse-mapped to the priority
    "complaint" bucket regardless of classifier confidence, per the brief's
    instruction that these should be flagged for priority handling.
"""
from __future__ import annotations

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from .intent_mapping import to_coarse
from .paths import data_path, models_path

MODEL_PATH = models_path("intent_classifier.joblib")


def load_hf_dataset() -> pd.DataFrame:
    try:
        from datasets import load_dataset

        ds = load_dataset(
            "bitext/Bitext-customer-support-llm-chatbot-training-dataset"
        )
        df = ds["train"].to_pandas()
        return df
    except Exception as e:  # pragma: no cover
        print(f"[intent_classifier] Falling back to sample data ({e})")
        return pd.read_csv(data_path("sample_support_kb.csv"))


def build_pipeline() -> Pipeline:
    vectorizer = TfidfVectorizer(
        analyzer="word",
        ngram_range=(1, 2),
        lowercase=True,
        stop_words="english",
        min_df=1,
        sublinear_tf=True,
    )
    clf = LinearSVC(C=1.0, class_weight="balanced")
    return Pipeline([("tfidf", vectorizer), ("clf", clf)])


def train(df: pd.DataFrame) -> tuple[Pipeline, pd.DataFrame, pd.DataFrame]:
    n_classes = df["intent"].nunique()
    can_stratify = df["intent"].value_counts().min() >= 2 and len(df) >= n_classes * 5
    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=42,
        stratify=df["intent"] if can_stratify else None,
    )
    pipeline = build_pipeline()
    pipeline.fit(train_df["instruction"], train_df["intent"])
    preds = pipeline.predict(test_df["instruction"])
    print("Fine-grained intent report:")
    print(classification_report(test_df["intent"], preds, zero_division=0))
    return pipeline, train_df, test_df


def predict_intent(pipeline: Pipeline, text: str) -> dict:
    fine_label = pipeline.predict([text])[0]
    # LinearSVC has no predict_proba; use decision_function margin as a
    # simple confidence proxy (softmax over per-class margins).
    import numpy as np

    scores = pipeline.decision_function([text])[0]
    scores = np.atleast_1d(scores)
    exp = np.exp(scores - scores.max())
    proba = exp / exp.sum()
    confidence = float(proba.max())
    coarse = to_coarse(fine_label)
    return {
        "fine_intent": fine_label,
        "coarse_intent": coarse,
        "confidence": confidence,
    }


def save(pipeline: Pipeline, path: str = MODEL_PATH) -> None:
    joblib.dump(pipeline, path)


def load(path: str = MODEL_PATH) -> Pipeline:
    return joblib.load(path)


if __name__ == "__main__":
    df = load_hf_dataset()
    pipeline, train_df, test_df = train(df)
    save(pipeline)
    print(predict_intent(pipeline, "I want to cancel my order please"))
    print(predict_intent(pipeline, "This product is awful, I'm furious"))
